-- phpMyAdmin SQL Dump
-- version 4.7.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Oct 17, 2019 at 01:44 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emenu_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `Category_ID` int(50) NOT NULL,
  `Category_Name` varchar(100) NOT NULL,
  `Category_Date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Delete_Flag` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`Category_ID`, `Category_Name`, `Category_Date`, `Delete_Flag`) VALUES
(1, 'Salad', '2019-10-17 14:59:43', 1),
(2, 'Drink', '2019-10-13 12:58:46', 1),
(3, 'Kitchen', '2019-10-13 12:58:54', 1),
(4, 'modified dishes', '2019-10-15 22:07:35', 1);

-- --------------------------------------------------------

--
-- Table structure for table `dishes`
--

CREATE TABLE `dishes` (
  `Dishes_Id` int(50) NOT NULL,
  `Category_ID` int(50) NOT NULL,
  `Sub_Category_Id` int(50) NOT NULL,
  `Dishes_Name` varchar(100) NOT NULL,
  `Dishes_Price` double NOT NULL,
  `Dishes_Photo` varchar(100) NOT NULL,
  `Dishes_Date` datetime(6) NOT NULL,
  `Delete_Flag` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dishes`
--

INSERT INTO `dishes` (`Dishes_Id`, `Category_ID`, `Sub_Category_Id`, `Dishes_Name`, `Dishes_Price`, `Dishes_Photo`, `Dishes_Date`, `Delete_Flag`) VALUES
(1, 1, 2, 'Thai Summer Grapefruit Salad', 3500, 'uploadimg/Thai_summer_grapefruit_salad_1571043727.webp', '2019-10-14 15:32:07.000000', 1),
(2, 1, 1, 'Vegan Rice Noodle Chinese Salad', 5200, 'uploadimg/Vegan-Rice-Noodle-Chinese-Salad_1571043753.jpg', '2019-10-14 15:32:33.000000', 1),
(3, 1, 2, 'Greens with Mango and Basil Dressing', 4500, 'uploadimg/Greens with Mango and Basil Dressing_1571043783.webp', '2019-10-14 15:33:03.000000', 1),
(4, 2, 4, 'Guaraná Antarctica', 1500, 'uploadimg/Guaraná Antarctica_1571043902.jpg', '2019-10-14 15:35:02.000000', 1),
(5, 2, 3, 'Ketel One Botanical Cucumber and Mint', 100000, 'uploadimg/Ketel One Botanical Cucumber and Mint_1571044056.png', '2019-10-14 15:37:36.000000', 1),
(6, 2, 4, 'Red Wine', 35000, 'uploadimg/red-wine_1571044334.jpg', '2019-10-14 15:42:14.000000', 1),
(7, 3, 5, 'Humburger', 4500, 'uploadimg/humburger_1571044421.jpg', '2019-10-14 15:43:41.000000', 1),
(8, 3, 5, 'Fish Nugget', 2500, 'uploadimg/fish_nugget_1571044500.jfif', '2019-10-14 15:45:00.000000', 1),
(9, 3, 5, 'Chicken Fried Rice', 4500, 'uploadimg/fish_nugget_1571059692.jfif', '2019-10-14 19:58:12.000000', 1),
(10, 4, 6, 'Fried Eggs', 600, 'uploadimg/fried_eggs_1571154427.jpg', '2019-10-15 22:17:08.000000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_total_payment`
--

CREATE TABLE `order_total_payment` (
  `payment_id` int(50) NOT NULL,
  `Transaction_Id` varchar(50) NOT NULL,
  `receipt_no` varchar(50) NOT NULL,
  `Total_Amount` int(50) NOT NULL,
  `Tax` int(50) NOT NULL,
  `Pay_Date` datetime(6) NOT NULL,
  `Delete_Flag` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_total_payment`
--

INSERT INTO `order_total_payment` (`payment_id`, `Transaction_Id`, `receipt_no`, `Total_Amount`, `Tax`, `Pay_Date`, `Delete_Flag`) VALUES
(1, '1', '00000556667#1', 7700, 700, '2019-10-17 12:51:53.000000', 1),
(2, '2', '00000522972#2', 4950, 450, '2019-10-17 12:56:40.000000', 1),
(3, '3', '00000155650#3', 13420, 1220, '2019-10-17 13:20:46.000000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_transaction_record`
--

CREATE TABLE `order_transaction_record` (
  `order_transation_id` int(11) NOT NULL,
  `transation_id` varchar(50) NOT NULL,
  `Category_ID` int(50) NOT NULL,
  `Sub_Category_Id` int(50) NOT NULL,
  `Dishes_Id` int(50) NOT NULL,
  `Quantity` int(50) NOT NULL,
  `Total_Price` int(100) NOT NULL,
  `TRecord_date` datetime(6) NOT NULL,
  `Delete_Flag` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `order_transaction_record`
--

INSERT INTO `order_transaction_record` (`order_transation_id`, `transation_id`, `Category_ID`, `Sub_Category_Id`, `Dishes_Id`, `Quantity`, `Total_Price`, `TRecord_date`, `Delete_Flag`) VALUES
(2, '1', 1, 2, 1, 2, 7000, '2019-10-17 12:51:34.000000', 1),
(5, '2', 1, 2, 3, 1, 4500, '2019-10-17 12:56:02.000000', 1),
(7, '3', 3, 5, 8, 1, 2500, '2019-10-17 13:06:29.000000', 1),
(8, '3', 3, 5, 7, 1, 4500, '2019-10-17 13:10:49.000000', 1),
(9, '3', 1, 1, 2, 1, 5200, '2019-10-17 13:20:30.000000', 1);

-- --------------------------------------------------------

--
-- Table structure for table `sub_category`
--

CREATE TABLE `sub_category` (
  `Sub_Category_Id` int(50) NOT NULL,
  `Category_ID` int(50) NOT NULL,
  `Sub_Category_Name` varchar(100) NOT NULL,
  `SubCategory_Date` datetime(6) NOT NULL,
  `Delete_Flag` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sub_category`
--

INSERT INTO `sub_category` (`Sub_Category_Id`, `Category_ID`, `Sub_Category_Name`, `SubCategory_Date`, `Delete_Flag`) VALUES
(1, 1, 'Chinese Salad', '2019-10-17 13:35:22.000000', 1),
(2, 1, 'Thai Salad  ', '2019-10-14 14:17:06.000000', 1),
(3, 2, 'Hard Drink', '2019-10-13 14:10:43.000000', 1),
(4, 2, 'Soft Drink', '2019-10-13 14:10:56.000000', 1),
(5, 3, 'Kitchen Foods ', '2019-10-13 14:36:09.000000', 1),
(6, 4, 'Modified Foods test', '2019-10-17 15:12:29.000000', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`Category_ID`);

--
-- Indexes for table `dishes`
--
ALTER TABLE `dishes`
  ADD PRIMARY KEY (`Dishes_Id`);

--
-- Indexes for table `order_total_payment`
--
ALTER TABLE `order_total_payment`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `order_transaction_record`
--
ALTER TABLE `order_transaction_record`
  ADD PRIMARY KEY (`order_transation_id`);

--
-- Indexes for table `sub_category`
--
ALTER TABLE `sub_category`
  ADD PRIMARY KEY (`Sub_Category_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `Category_ID` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `dishes`
--
ALTER TABLE `dishes`
  MODIFY `Dishes_Id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `order_total_payment`
--
ALTER TABLE `order_total_payment`
  MODIFY `payment_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `order_transaction_record`
--
ALTER TABLE `order_transaction_record`
  MODIFY `order_transation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `sub_category`
--
ALTER TABLE `sub_category`
  MODIFY `Sub_Category_Id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
