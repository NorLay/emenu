<?php
  include('connect.php');
  $SubCategoryID = $_GET['SubCategoryID'];
  $sql = "DELETE FROM sub_category WHERE Sub_Category_Id =  '$SubCategoryID'";
  $conn->query($sql);
  header('location:sub_category.php');
?>