<?php
	include('connect.php');

	$category_name=$_POST['category_name'];
	//echo $category_name; exit;
	
	//echo gettype($date); exit;
	$delete_Flag = 1;
    $sql="INSERT INTO category (Category_Name, Category_Date, Delete_Flag) VALUES ( '$category_name', NOW(), '$delete_Flag')";
    //echo "haha";exit;
	$conn->query($sql);
    header('location:category.php');

?> 