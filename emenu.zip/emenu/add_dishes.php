<?php
   include('connect.php');
   $dishes_name = $_POST['dishes_name'];
   $fileinfo=PATHINFO($_FILES["dishes_photo"]["name"]);

	  if(empty($fileinfo['filename'])){
		    $location="";
	  }
	  else{
    		$newFilename=$fileinfo['filename'] ."_". time() . "." . $fileinfo['extension'];
    		move_uploaded_file($_FILES["dishes_photo"]["tmp_name"],"uploadimg/" . $newFilename);
    		$imglocation="uploadimg/" . $newFilename;
    }

    $dishes_price = $_POST['dishes_price'];
    $category_name_list = $_POST['category_name_list'];
    //echo "namelist = " . $category_name_list ;exit;
    $query = "Select Category_ID From category WHERE Category_Name = '$category_name_list' ";
    $result= $conn->query($query);
    while($row=$result->fetch_array()){
      $category_id = $row['Category_ID'];
     

       /*echo "category id=" . $category_id; */
    }

    $sub_category_name_list = $_POST['sub_category_name_list'];
    $query_sub = "Select Sub_Category_Id From sub_category WHERE Sub_Category_Name = '$sub_category_name_list' ";
    $result_sub= $conn->query($query_sub);
    while($rowsub=$result_sub->fetch_array()){
      $sub_category_id = $rowsub['Sub_Category_Id'];
      

       /*echo "sub category id=" . $sub_category_id;  exit;*/
    }


    $Delete_Flag = 1;
    /*echo "disheds name " .  $dishes_name . "<br/>" . $imglocation . "<br/>" . $category_name_list . "<br/>" . $sub_category_name_list , "<br/>" . $category_id . "<br/>" . $sub_category_id  . "<br/>" . $Delete_Flag ;
    exit;*/

    $sql="INSERT INTO dishes ( Category_ID , Sub_Category_Id , Dishes_Name , Dishes_Price , Dishes_Photo , Dishes_Date , Delete_Flag) VALUES ('$category_id' , '$sub_category_id', '$dishes_name', '$dishes_price', '$imglocation',NOW(), '$Delete_Flag')";


    $conn->query($sql);
    header('location:dishes.php');

?>