<?php
    include('connect.php');
    $CategoryID = $_GET['CategoryID'];
	$category_name=$_POST['category_name'];
	//echo $category_name; exit;

	$sql = "DELETE FROM category WHERE Category_ID =  '$CategoryID'";
	$conn->query($sql);
    header('location:category.php');

?>

