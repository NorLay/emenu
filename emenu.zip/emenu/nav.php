<div class="row pt-2">
    		<div class="col-md-5">
    	         <h1>
    	         	Emenu
    	         </h1>
			    
    	    </div>
    	    <div class="col-md-7">
    	    	   <ul class="nav nav-pills">
					    <li class="nav-item">
					      <a class="nav-link active" href="index.php">Home</a>
					    </li>
					    <li class="nav-item">
					      <a class="nav-link" href="View/modified_foods.php">Modified Foods</a>
					    </li>
					    <li class="nav-item">
					      <a class="nav-link" href="View/order_list.php">Orders</a>
					    </li>
					    <li class="nav-item dropdown">
					      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">For admin panel</a>
					      <div class="dropdown-menu">
					        <a class="dropdown-item" href="category.php">Categoires</a>
					        <a class="dropdown-item" href="sub_category.php">Sub Categories</a>
					        <a class="dropdown-item" href="dishes.php">Dishes</a></div>
					    </li>
					    
					    
				  </ul>
    	    	  
            </div>

        </div>