<?php include('header.php'); ?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('nav.php'); ?>
        <!-- end header top -->
        <!-- start categories list view -->
        <div class="row">
                <div class="col-md-12"><h2> Categories </h2></div>

                <!-- for add category  -->
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addcategory">Add New Category</button>
                        <div class="modal fade" id="addcategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Add New Category</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="add_category.php" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="category-name" class="col-form-label">Category Name</label>
								            <input type="text" class="form-control" id="category_name" name="category_name">
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-primary">Save</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>

                <!-- end for add category -->
                <table class="table table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Category Name</th>
				      <th scope="col">Edit</th>
				      <th scope="col">Delete</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
					$sql="select * from category order by Category_ID asc";
					$query=$conn->query($sql);
					
					while($row=$query->fetch_array()){
						$no += 1;
						?>
						<tr>
							<th scope="row"><?php echo $no ; ?></th>
							<td><?php echo $row['Category_Name']; ?></td>
							<td>
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#editcategory<?php echo $row['Category_ID']; ?>">Edit</button>
							</td>
							<td>
							    <button type="button" class="btn btn-danger " data-toggle="modal" data-target="#deletecategory<?php echo $row['Category_ID']; ?>">Delete</button>
							</td>
						</tr>

						<!-- start Edit Category modal box  -->

                  
                        <div class="modal fade" id="editcategory<?php echo $row['Category_ID']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">EditCategory</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="edit_category.php?CategoryID=<?php echo $row['Category_ID']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="category-name" class="col-form-label">Category Name</label>
								            <input type="text" class="form-control" id="category_name" value='<?php echo $row['Category_Name']; ?> ' name="category_name">
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-primary">Save</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>

               
                        <!-- end Edit Category modal box-->


                        <!--  start Delete Category modal box -->
                         <div class="modal fade" id="deletecategory<?php echo $row['Category_ID']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Delete Category</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="delete_category.php?CategoryID=<?php echo $row['Category_ID']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="category-name" class="col-form-label">Category Name : <?php echo $row['Category_Name']; ?></label>
								            
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-danger">Delete</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>


                        <!-- end Delete Category modal box  -->
						<?php
					}
				?>
				   
				  </tbody>
				</table>
        <div>

       
        <!-- end categories list views -->
        
        </div>
         
    </div>

</body>
</html>