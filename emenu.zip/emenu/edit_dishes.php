<?php
	include('connect.php');
    $Dishes_Id = $_GET['Dishes_Id'];
    
    $dishes_name=$_POST['dishes_name'];
    $dishes_price = $_POST['dishes_price'];
    $edit_category_list = $_POST['edit_category_list'];
    $edit_subcategory_list = $_POST['edit_subcategory_list'];
	/*echo $Dishes_Id ."//" . $dishes_name . "//" . $dishes_price . "//" . $edit_category_list . "//" . $edit_subcategory_list ; exit;*/
	$sql="UPDATE dishes SET Category_ID='$edit_category_list' , Sub_Category_Id = '$edit_subcategory_list' , Dishes_Name = '$dishes_name' , Dishes_Price = '$dishes_price' , Dishes_Date = NOW() WHERE Dishes_Id =  '$Dishes_Id' ";
    
	$conn->query($sql);
    header('location:dishes.php');
	 
   

?> 