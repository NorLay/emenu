<?php include('connect.php')?>
<div class="container">
   <div class="row">
   	      <div class="col-md-12 p-4">
              <h2 class="text-center">Salads / Drinks / Kitchen</h2>
   	      </div>
   	      <?php
   	         $Category_ID = 1;
			 $sql="select * from dishes order by Dishes_Id asc";
			 $query=$conn->query($sql);
			 while($row=$query->fetch_array()){
													
			?>
			<div class="col-md-4">
				 <div class="card" style="width: 18rem;">
                  <img  src="<?php if(empty($row['Dishes_Photo'])){echo "upload/noimage.jpg";} else{echo $row['Dishes_Photo'] ;} ?>" class="img-responsive">
				  <div class="card-body">
				    <h5 class="card-title"> <?php echo $row['Dishes_Name'] ?></h5>
				    <p class="card-text"> Prices : <?php echo $row['Dishes_Price'] ?> MMK </p>
				    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#gocorner">Order Foods</button>
				    <!-- start for modal box go to each corner -->
                         <div class="modal fade" id="gocorner" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Order item alert</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="delete_category.php?CategoryID=<?php echo $row['Category_ID']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="category-name" class="col-form-label">To order foods go to each corner.</label>
								            <img src="img/banner.jpg">
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-success" data-dismiss="modal">Close</button>
								       
								        </form>
								      </div>
								    </div>
  								</div>
						</div>
				    <!-- end for modual box go to each corner -->
				  </div>
           </div>
                  
			</div>

			
            
            <?php    
			}
            ?>


   	      
          
   </div>
</div>