<?php include('../connect.php')?>
<body>
    <div class="container_fluid">
      <div class="container">

      <!-- start header top -->
      <?php include('frontnav.php'); ?>
        <!-- end header top -->
       
        
         <div class="row">
          <div class="col-md-12 p-4">
              <h2 class="text-center">Drinks </h2>
          </div>
          <?php
             $Category_ID = 2;
             $sql="select * from dishes WHERE Category_ID = $Category_ID order by Dishes_Id asc";
             $query=$conn->query($sql);
             while($row=$query->fetch_array()){
                          
          ?>
       <div id="order" class="col-md-4">
         <div class="card" style="width: 18rem;">
                  <img  src="<?php if(empty($row['Dishes_Photo'])){echo "../upload/noimage.jpg";} else{echo "../".$row['Dishes_Photo'] ;} ?>" class="img-responsive">
            <div class="card-body">
            <h5 class="card-title"> <?php echo $row['Dishes_Name'] ?></h5>
            <p class="card-text"> Prices : <?php echo $row['Dishes_Price'] ?> MMK </p>
            
            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#orderitem<?php echo $row['Dishes_Id']; ?>">Order Foods</button>
            <!-- start modal oder item -->
 
                   <div class="modal fade" id="orderitem<?php echo $row['Dishes_Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Order Dishes</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form method="POST" action="add_orders.php" enctype="multipart/form-data">
                          <div class="row">
                             <div class="col-md-5">
                                  <img  src="<?php if(empty($row['Dishes_Photo'])){echo "../upload/noimage.jpg";} else{echo "../".$row['Dishes_Photo'] ;}?>" name="Dishes_Photo" class="img-responsive">
                                  <input type="hidden" name="Dishes_Id" value="<?php echo $row['Dishes_Id'] ?>" >
                                  <input type="hidden" name="Category_ID" value="<?php echo $row['Category_ID'] ?>" >
                                  <input type="hidden" name="Sub_Category_Id" value="<?php echo $row['Sub_Category_Id'] ?>" >
                             </div>
                             
                             <div class="col-md-7">
                                  <!-- Name -->
                                   <div class="row pt-2 pb-2">
                                       <div class="col-md-2">
                                          <label for="dishes_name" class="col-form-label">Name</label> 
                                       </div>
                                       <div class="col-md-1">
                                          : 
                                       </div>
                                       <div class="col-md-9">
                                           <input type="text" class="form-control" name="dishes_name" value="<?php echo $row['Dishes_Name'] ?>" readonly />
                                           
                                       </div>
                                   </div>

                                   <!-- price -->
                                   <div class="row pt-2 pb-2">
                                       <div class="col-md-2">
                                           <label for="dishes_prices" class="col-form-label">Price</label> 
                                       </div>
                                       <div class="col-md-1">
                                          : 
                                       </div>
                                       <div class="col-md-9">
                                           <input type="text" class="form-control" name="dishes_prices" value=" <?php echo $row['Dishes_Price'] ?> MMK" readonly />
                                          
                                       </div>
                                   </div>

                                   <!-- start quaytity increase decrease -->
                                    <div class="row pt-2 pb-2">
                                       <div class="col-md-2">
                                          <label for="dishes_qty" class="col-form-label">Qty</label>
                                       </div>
                                       <div class="col-md-1">
                                          : 
                                       </div>
                                       <div class="col-md-9">
                                        <div class="center">
                                            <div class="input-group">
                                                  <table style="width:140px;">
                                                     <tr>
                                                        <td>
                                                           <span class="input-group-btn">
                                                                <button type="button" class="btn btn-success btn-number"  data-type="minus" data-field="dishes_qty">
                                                                 <i class="fa fa-minus"></i>
                                                                </button>
                                                            </span>
                                                        </td>
                                                        <td style="text-align: center;"> <input type="text" name="dishes_qty" class="form-control input-number" value="1" min="1" max="10" width="30px" ></td>
                                                        <td>
                                                           <span class="input-group-btn">
                                                                <button type="button" class="btn btn-success btn-number" data-type="plus" data-field="dishes_qty">
                                                                   <i class="fas fa-plus"></i>
                                                                </button>
                                                            </span>
                                                        </td>
                                                     </tr>

                                                  </table>
                                                 
                                                 
                                                 
                                              </div>
                                       
                                            </div>
                                          
                                       </div>
                                   </div>

                                      


                                   <!-- end quantity increase decrease -->
                                    
                             </div>
                           
                          </div>
                        
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Remove Order</button>
                        <button type="submit" class="btn btn-primary">Confirm Dishes</button>
                        </form>
                      </div>
                    </div>
                  </div>
            </div>

            
            <!-- end for modal order item -->
          </div>
            </div>
                  
      </div>

      
            
            <?php    
      }
            ?>

            
           </div>
        </div>
     </div>

     <!-- for increase and descrease js -->
     <script>
     $('.btn-number').click(function(e){
          e.preventDefault();
          
          fieldName = $(this).attr('data-field');
          type      = $(this).attr('data-type');
          var input = $("input[name='"+fieldName+"']");
          var currentVal = parseInt(input.val());
          if (!isNaN(currentVal)) {
              if(type == 'minus') {
                  
                  if(currentVal > input.attr('min')) {
                      input.val(currentVal - 1).change();
                  } 
                  if(parseInt(input.val()) == input.attr('min')) {
                      $(this).attr('disabled', true);
                  }

              } else if(type == 'plus') {

                  if(currentVal < input.attr('max')) {
                      input.val(currentVal + 1).change();
                  }
                  if(parseInt(input.val()) == input.attr('max')) {
                      $(this).attr('disabled', true);
                  }

              }
          } else {
              input.val(0);
          }
      });
      $('.input-number').focusin(function(){
         $(this).data('oldValue', $(this).val());
      });
      $('.input-number').change(function() {
          
          minValue =  parseInt($(this).attr('min'));
          maxValue =  parseInt($(this).attr('max'));
          valueCurrent = parseInt($(this).val());
          
          name = $(this).attr('name');
          if(valueCurrent >= minValue) {
              $(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
          } else {
              alert('Sorry, the minimum value was reached');
              $(this).val($(this).data('oldValue'));
          }
          if(valueCurrent <= maxValue) {
              $(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
          } else {
              alert('Sorry, the maximum value was reached');
              $(this).val($(this).data('oldValue'));
          }
    
    
    });
    $(".input-number").keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 190]) !== -1 ||
             // Allow: Ctrl+A
            (e.keyCode == 65 && e.ctrlKey === true) || 
             // Allow: home, end, left, right
            (e.keyCode >= 35 && e.keyCode <= 39)) {
                 // let it happen, don't do anything
                 return;
        }
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    </script>
</body>
</html>