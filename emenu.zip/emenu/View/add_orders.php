<?php
    include('../connect.php');
	$dishes_name = $_POST['dishes_name'];
	$dishes_price = $_POST['dishes_prices'];
	$dishes_qty = $_POST['dishes_qty'];
	$Category_ID = $_POST['Category_ID'];
	$Sub_Category_Id = $_POST['Sub_Category_Id'];
	$Dishes_Id = $_POST['Dishes_Id'];
	//echo "categoryID =" . $Category_ID . "Sub Cate =" .  $Sub_Category_Id . "Dishes_Id = " . $Dishes_Id; exit;
	$Total_Price = $dishes_price * $dishes_qty;

	/*$array = array("name" =>  $dishes_name, "price" => $dishes_price , "quantity" , $dishes_qty);*/
	/*print_r(array_values($array));*/
	/*generate transaction id*/;
	$delete_Flag = 1;
	$uniqueTransId= 1;
	
    $result="select * from order_total_payment" ;
	$query=$conn->query($result);
		/*for check if have already this transition in final */
			while($row=$query->fetch_array()){
				    $uniqueTransId = $row['Transaction_Id'];
				    
					if($uniqueTransId != $uniqueTransId){
						$uniqueTransId += 1;
						
					}
					else{
                        $uniqueTransId += 1;
                        
					}

					


			}

	 
   
     $sql="INSERT INTO order_transaction_record ( transation_id , Category_ID , Sub_Category_Id , Dishes_Id , Quantity , Total_Price , TRecord_date , Delete_Flag) VALUES ('$uniqueTransId' ,  '$Category_ID'  , '$Sub_Category_Id', $Dishes_Id , $dishes_qty , $Total_Price ,NOW(), '$delete_Flag')";
    
	$conn->query($sql);
    header('location:orders.php');


?>