<?php
    include('../connect.php');
    $order_transation_id = $_GET['order_transation_id'];
    $transation_id = $_POST['transation_id'];

    //echo $order_transation_id . "//" . $transtion_id; exit;
    $sql_pay = "select * from order_total_payment ORDER BY Transaction_Id DESC LIMIT 1";
    $result_pay = $conn->query($sql_pay);
    $row_pay = $result_pay->fetch_assoc();
    $pay_last_trans_id = $row_pay['Transaction_Id'];	

    if($transation_id != $pay_last_trans_id ){
       $sql = "DELETE FROM order_transaction_record WHERE order_transation_id = $order_transation_id";	
       $conn->query($sql);
       header('location:orders.php');
    }
    else{
       header('location:order_list.php');
      
    }

	
	

?>

