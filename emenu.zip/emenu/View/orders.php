<?php include('../connect.php')?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('frontnav.php'); ?>
        <!-- end header top -->
         <?php
                        $last_query = "SELECT transation_id , Category_ID FROM order_transaction_record ORDER BY order_transation_id DESC LIMIT 1";
						$result = $conn->query($last_query);
						$row = $result->fetch_assoc();
						$last_trans_id = $row['transation_id'];
						$Category_ID = $row['Category_ID'];
						if($Category_ID == '1'){
                            $url = "Salad.php";
						}else if($Category_ID == '2'){
                            $url = "Drink.php";
						}else if($Category_ID == '3'){
                           $url = "Kitchen.php";
						}
						else{
							$url = "../index.php";
						}
         ?>
         <a href=<?php echo $url ?>><button type="button" class="btn btn-primary">get more foods</button></a>
         <div class="row">
   	      <div class="col-md-12 p-4">
              <h2 class="text-center">Show orders list </h2>
   	      </div>
   	      
			<div class="col-md-12">
				
				<table class="table table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Qty</th>
				      <th scope="col">Description</th>
				      <th scope="col">Amount </th>
				      <th scope="col">Delete</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php

				  	    

						//echo "trans-id =" . $last_trans_id;exit;   	        
						 $sql="select * from order_transaction_record rec join dishes d WHERE d.Dishes_Id = rec.Dishes_Id";

						 $query=$conn->query($sql);
						 while($row=$query->fetch_array()){

						 	if($row['transation_id'] == $last_trans_id ){
							 	$no +=1;	
								$quantiy = $row['Quantity'];
								$total_Price =$row['Total_Price'];
								$price =  $total_Price / $quantiy;	
						 	
								

						 ?>
				  	   <tr>
						<td scope="row"><?php echo $no ; ?></td>
						<td><?php echo $quantiy ." x " . $price;?> </td>
						<td><?php echo $row['Dishes_Name']; ?></td>
						<td><?php echo $total_Price ;?></td>
							
						<td>
							    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deleteorder<?php echo $row['order_transation_id']; ?>"><span aria-hidden="true">&times;</span></button>
						</td>
					</tr>
				  	


                        <!--  start Delete Category modal box -->
                         <div class="modal fade" id="deleteorder<?php echo $row['order_transation_id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Delete Order Item</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="delete_order.php?order_transation_id=<?php echo $row['order_transation_id']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="order_transation_id" class="col-form-label">Do you want to really remove this item?</label>
								            
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-danger">Delete</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>
						<?php 
						}   
			          }
                     ?>
                    <!-- subtotals -->
                    <tr>
                      <td  scope="row" colspan="3">
                      	  Sub Totals

                      </td>
                      <td colspan="2">
                      	<?php
   	        
						 $sql="select SUM(Total_Price) as sub_total ,  transation_id from order_transaction_record GROUP BY transation_id DESC LIMIT 1";

						 //echo $sql;
						 $query=$conn->query($sql);
						 while($row=$query->fetch_array()){
							
							echo $total_Price = $row['sub_total'] ." " . "MMK";
						  ?>
						 


                      </td>
                      </tr>
                      <!-- tax -->
                      <tr>
                      <td  scope="row" colspan="3">
                      	  Tax 10% 
                      </td>
                      <td colspan="2">
                      	 <?php $tax_per = 0.1 ;
                      	    $tax = $row['sub_total'] * $tax_per ;
                      	    echo $tax .  " " . "MMK" ;
                      	 ?>

                      </td>
                      <tr>
                           <td  scope="row" colspan="3">
                                Total 
                           </td>
                           <td colspan="2">
                             <?php
                                $total =  $row['sub_total'] + $tax ;
                                echo $total . " " . "MMK" ;
                             ?> 	

                           </td>
                         <?php
                          }	
                         ?> 
                          
                      </tr>
                     
                      <tr>
                         <td colspan="5">
                         	<h3>**** if no more order items , click "Complete Orders" button.</h3>

                         </td>

                      </tr>
                      <tr>
                         <td colspan="4"></td>
                         <td>
                           
                         	<a href="add_total_payment.php?Transaction_ID=<?php echo $last_trans_id; ?>"> <button type="submit" class="btn btn-primary">Complete Orders</button></a>
                         </td>
                         
                      </tr>

                     

                        <!-- end Delete Category modal box  -->
					
				   
				  </tbody>
				</table>
                  
			</div>

			
            
            
           </div>
        </div>
     </div>
</body>
</html>