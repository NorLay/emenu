<?php include('../connect.php')?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('frontnav.php'); ?>
        <!-- end header top -->
       
        
         <div class="row payment_wrap">
   	      <div class="col-md-12 p-4">
              <h2 class="text-center"> Print Payment Slice</h2>
   	      </div>
   	      
			<div class="col-md-6 slice pt-4">
				<?php
                    
				  	    $last_query = "SELECT transation_id , Pay_Date , receipt_no FROM order_transaction_record as rec JOIN order_total_payment as pay WHERE pay.Transaction_Id = rec.transation_id ORDER BY order_transation_id DESC LIMIT 1";
						$result = $conn->query($last_query);
						$row = $result->fetch_assoc();
						$last_trans_id = $row['transation_id'];
						$Pay_Date = $row['Pay_Date'];
						$receipt_no = $row['receipt_no'];
				?>
				<h5> <?php echo "Date : ". $Pay_Date ?> </h5>
				<h5> <?php echo "Receipt No : ". $receipt_no ?> </h5>
				<table class="table table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Qty</th>
				      <th scope="col">Description</th>
				      <th scope="col">Amount </th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php


						//echo "trans-id =" . $last_trans_id;exit;   	        
						 $sql="select * from order_transaction_record rec join dishes d WHERE d.Dishes_Id = rec.Dishes_Id";

						 $query=$conn->query($sql);
						 while($row=$query->fetch_array()){

						 	if($row['transation_id'] == $last_trans_id ){
							 	$no +=1;	
								$quantiy = $row['Quantity'];
								$total_Price =$row['Total_Price'];
								$price =  $total_Price / $quantiy;	
						 	
								

						 ?>
				  	   <tr>
						<td scope="row"><?php echo $no ; ?></td>
						<td><?php echo $quantiy ." x " . $price;?> </td>
						<td><?php echo $row['Dishes_Name']; ?></td>
						<td><?php echo $total_Price ;?></td>
						
					</tr>
				  	


                        
						<?php 
						}   
			          }
                     ?>
                    <!-- subtotals -->
                    <tr>
                      <td  scope="row" colspan="3">
                      	  Sub Totals

                      </td>
                      <td colspan="2">
                      	<?php
   	        
						 $sql="select SUM(Total_Price) as sub_total ,  transation_id from order_transaction_record GROUP BY transation_id DESC LIMIT 1";

						 //echo $sql;
						 $query=$conn->query($sql);
						 while($row=$query->fetch_array()){
							
							echo $total_Price = $row['sub_total'] ." " . "MMK";
						  ?>
						 


                      </td>
                      </tr>
                      <!-- tax -->
                      <tr>
                      <td  scope="row" colspan="3">
                      	  Tax 10% 
                      </td>
                      <td colspan="1">
                      	 <?php $tax_per = 0.1 ;
                      	    $tax = $row['sub_total'] * $tax_per ;
                      	    echo $tax .  " " . "MMK" ;
                      	 ?>

                      </td>
                      <tr>
                           <td  scope="row" colspan="3">
                                Total 
                           </td>
                           <td colspan="1">
                             <?php
                                $total =  $row['sub_total'] + $tax ;
                                echo $total . " " . "MMK" ;
                             ?> 	

                           </td>
                         <?php
                          }	
                         ?> 
                          
                      </tr>
                     
                      <tr>
                         <td colspan="3"></td>
                         <td>
                           
                         	<button type="submit" onclick="myFunction()" class="btn btn-primary print-btn">Print</button>
                         </td>
                         
                      </tr>

                     

                        
				   
				  </tbody>
				</table>
                  
			</div>

			
            
            
           </div>
           
        </div>
     </div>
     <script>
		function myFunction() {
		  window.print();
		}
      </script>
</body>
</html>