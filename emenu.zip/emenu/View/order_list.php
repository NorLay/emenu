<?php include('../connect.php')?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('frontnav.php'); ?>
        <!-- end header top -->
        <?php
            $sql_rec = "select * from order_transaction_record ORDER BY transation_id DESC LIMIT 1";
            $result_rec = $conn->query($sql_rec);
			$row_rec = $result_rec->fetch_assoc();
			$rec_last_trans_id = $row_rec['transation_id'];

			$sql_pay = "select * from order_total_payment ORDER BY Transaction_Id DESC LIMIT 1";
            $result_pay = $conn->query($sql_pay);
			$row_pay = $result_pay->fetch_assoc();
			$pay_last_trans_id = $row_pay['Transaction_Id'];

			if($rec_last_trans_id == $pay_last_trans_id){
				include('order_record.php');
			}
			else{
                include('current_order.php');
			}

             

	  
        ?>
       
        </div>
     </div>
</body>
</html>