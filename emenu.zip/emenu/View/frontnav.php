
<?php include('connect.php'); ?>
<!DOCTYPE html>
<html>
<head> 
    <title>emenu</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.min.css">
    <script src="../jquery/jquery.min.js"></script>
    <script src="../js/popper.min.js"></script>
    <script src="../bootstrap/js/bootstrap.min.js"></script>
	
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    
</head>
<div class="row pt-2">
    		<div class="col-md-5">
    	         <h1>
    	         	Emenu
    	         </h1>
			    
    	    </div>
    	    <div class="col-md-7">
    	    	   <ul class="nav nav-pills">
					    <li class="nav-item">
					      <a class="nav-link active" href="../index.php">Home</a>
					    </li>
					    <li class="nav-item">
					      <a class="nav-link" href="modified_foods.php">Modified Foods</a>
					    </li>
					    <li class="nav-item">
					      <a class="nav-link" href="order_list.php">Orders</a>
					    </li>
					    <li class="nav-item dropdown">
					      <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">For admin panel</a>
					      <div class="dropdown-menu">
					        <a class="dropdown-item" href="../category.php">Categoires</a>
					        <a class="dropdown-item" href="../sub_category.php">Sub Categories</a>
					        <a class="dropdown-item" href="../dishes.php">Dishes</a></div>
					    </li>
					    
					    
				  </ul>
    	    	  
            </div>

        </div>