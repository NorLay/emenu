<?php
    include('../connect.php');
	$Transaction_Id = $_GET['Transaction_ID'];
	$generate = "00000".rand(1, 1000000);
	

	$sql_order_record = "select SUM(Total_Price) as sub_total ,  transation_id from order_transaction_record GROUP BY transation_id ";
	$query=$conn->query($sql_order_record);
		while($row=$query->fetch_array()){	
		     $no += 1;
	         $receipt_no= $generate."#".$no ;	
			 $total_Price = $row['sub_total'];
			 $tax_per = 0.1;
			 $tax = $total_Price * $tax_per ;
			 $total_amount = $total_Price + $tax;

		}
    //echo "transaction :" . $Transaction_Id; exit;
	 $delete_Flag = 1;
	 
   
     $sql="INSERT INTO order_total_payment ( Transaction_Id , receipt_no , Total_Amount , Tax , Pay_Date , 	Delete_Flag ) VALUES ('$Transaction_Id' ,  '$receipt_no'  , '$total_amount', $tax ,NOW(), '$delete_Flag')";
    
	$conn->query($sql);
    header('location:order_slice.php');


?>