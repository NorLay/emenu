
 <div class="row">
    <div class="col-md-12"><h2> Order list </h2></div>
        <table class="table table-hover">
			<thead>
				<tr>
				    <th scope="col">#</th>
				    <th scope="col">Dishes Name</th>
				    <th scope="col">Price</th>
				    <th scope="col">Quantity</th>
				    <th scope="col">Total Price</th>
				    <th scope="col">Category</th>
				 </tr>
		    </thead>
		    <tbody>
		    	<?php
		    	$sql="select * from order_transaction_record rec join dishes d WHERE d.Dishes_Id = rec.Dishes_Id";

						 $query=$conn->query($sql);
						 while($row=$query->fetch_array()){
							 	$no +=1;	
							 	$Dishes_name = $row['Dishes_Name'];
								$quantiy = $row['Quantity'];
								$total_Price =$row['Total_Price'];
								$price =  $total_Price / $quantiy;
								$Category = $row['Category_ID'];

								$cat_sql = "select * from category WHERE Category_ID = $Category";
								$result = $conn->query($cat_sql);
			                    $row_cat = $result->fetch_assoc();
			                    $category_name = $row_cat['Category_Name'];	
						 	
								

			    ?>
                <tr>
                	<td><?php echo $no ?></td>
                	<td><?php echo $Dishes_name ?></td>
                	<td><?php echo $price ?></td>
                	<td><?php echo $quantiy ?></td>
                	<td><?php echo $total_Price ?></td>
                	<td><?php echo $category_name ?></td>
                	

                </tr>
                <?php
                   }
                ?>

		    </tbody>

		
</div>
   