<?php
    include('connect.php');
    $DishesID = $_GET['DishesID'];

	$sql = "DELETE FROM dishes WHERE Dishes_Id =  '$DishesID'";
	$conn->query($sql);
    header('location:dishes.php');

?>

