<?php

$conn = new mysqli('localhost', 'root', '12345678', 'emenu_system');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>