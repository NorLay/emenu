<?php
	include('connect.php');
    $SubCategoryID = $_GET['SubCategoryID'];
	$sub_category_name=$_POST['sub_category_name'];
	//echo $SubCategoryID; exit;
	
	
	$delete_Flag = 1;
	 
    $sql="UPDATE sub_category SET Sub_Category_Name='$sub_category_name' , SubCategory_Date = NOW() 
    WHERE Sub_Category_Id =  '$SubCategoryID' ";
    
	$conn->query($sql);
    header('location:sub_category.php');

?> 