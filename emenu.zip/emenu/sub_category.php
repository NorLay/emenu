<?php include('header.php'); ?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('nav.php'); ?>
        <!-- end header top -->
        <!-- start categories list view -->
        <div class="row">
                <div class="col-md-12"><h2> Sub Categories </h2></div>

                <!-- for add new sub category  -->
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addsubcategory">Add New Sub Category</button>
                        <div class="modal fade" id="addsubcategory" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Add New Sub Category</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="add_subcategory.php" enctype="multipart/form-data">
								          <div class="form-group">
									            <label for="category-name" class="col-form-label">Sub Category Name</label>
									            <input type="text" class="form-control" id="sub_category_name" name="sub_category_name">
								          
								          </div>
								          <div class="form-group">
								           
								            <select name ="category_name_list" class="form-control">
								            	<option>Choose Categories Type</option>
								           <?php
												$sql="select * from category order by Category_ID asc";
												$query=$conn->query($sql);
												
												while($row=$query->fetch_array()){
													
													?>
                                             <option value="<?php echo $row['Category_Name'] ?>"> <?php echo $row['Category_Name'] ?></option>
                                             <?php    
					                         }

                                             ?>
 												 
											</select>
										   
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-primary">Save</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>

                <!-- end for add category -->
                <table class="table table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Sub Category Name</th>
				      <th scope="col">Category Name</th>
				      <th scope="col">Edit</th>
				      <th scope="col">Delete</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
					$sql="select * from sub_category order by Sub_Category_Id asc" ;
					$query=$conn->query($sql);
					
					while($row=$query->fetch_array()){
						$sub_category_name = $row['Sub_Category_Name'];
						$choose_cat_id = $row['Category_ID']; 
						$cat_query = "select Category_Name from category WHERE Category_ID = $choose_cat_id ";
						$query_cat=$conn->query($cat_query);
						/*for category name are shown in list view */
						while($rowcat=$query_cat->fetch_array()){
							$Category_Name = $rowcat['Category_Name'];
						}
					
						$no += 1;
						?>
						<tr>
							<th scope="row"><?php echo $no ; ?></th>
							<td><?php echo $sub_category_name ?></td>
							<td><?php echo $Category_Name ?></td>
							<td>
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#editsubcategory<?php echo $row['Sub_Category_Id']; ?>">Edit</button>
							</td>
							<td>
							    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deletesubcategory<?php echo $row['Sub_Category_Id']; ?>">Delete</button>
							</td>
						</tr>

						<!-- start Edit sub Category modal box  -->

                  
                        <div class="modal fade" id="editsubcategory<?php echo $row['Sub_Category_Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Edit Sub Category</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="edit_sub_category.php?SubCategoryID=<?php echo $row['Sub_Category_Id']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="category-name" class="col-form-label">Sub Category Name</label>
								            <input type="text" class="form-control" id="sub_category_name" value='<?php echo $row['Sub_Category_Name']; ?> ' name="sub_category_name">
								          </div>
                                          <div class="form-group">
                                            <label for="category-name" class="col-form-label">Category Name</label>
								           
                                          	<input type="text" class="form-control" id="category_name" value='<?php echo $Category_Name; ?> ' name="category_name" readonly>
                                          	   
								           </div>
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-primary">Save</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>

               
                        <!-- end Edit Category modal box-->


                        <!--  start Delete  Sub Category modal box -->
                         <div class="modal fade" id="deletesubcategory<?php echo $row['Sub_Category_Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Delete Sub Category</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="delete_sub_category.php?SubCategoryID=<?php echo $row['Sub_Category_Id']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="subcategory-name" class="col-form-label">Sub Category Name : <?php echo $row['Sub_Category_Name']; ?></label>
								            
								          </div>
								          
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-danger">Delete</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>


                        <!-- end Delete Category modal box  -->
						<?php
					}
				?>
				   
				  </tbody>
				</table>
        <div>

       
        <!-- end categories list views -->
        
        </div>
         
    </div>

</body>
</html>