<?php include('header.php'); ?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('nav.php'); ?>
        <!-- end header top -->
        <!-- start content -->
        <div class="row cat_menu">
                <?php 
                   $sql = "select * from category ORDER BY Category_ID asc LIMIT 3";
                    $query=$conn->query($sql);
                 while($row=$query->fetch_array()){
                                                    
                 ?>
                <div class="col-md-4">
                      <h2><a href="View/<?php echo $row['Category_Name'] ?>.php"><?php echo $row['Category_Name'] ?></a></h2>
                </div>
                <?php
                  }

                ?>
               
        </div>



        <!-- start for salad prodcuts -->
        <div class="row salad">
                <?php 
                include('View/salad_list.php') ; 

                ?>
                
        </div>
        <!-- end for salad Products  -->
        <!-- end content -->
        </div>
         
    </div>

</body>
</html>