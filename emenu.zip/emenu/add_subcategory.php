<?php
	include('connect.php');
    $sub_category_name = $_POST['sub_category_name'];
	$category_name=$_POST['category_name_list'];
	//echo $sub_category_name . "" . $category_name . "<br/>" ;

	$query = "Select Category_ID From category WHERE category_name = '$category_name' ";
	$result= $conn->query($query);
    while($row=$result->fetch_array()){
    	$category_id = $row['Category_ID'];
    	 //echo "category id=" . $category_id; 
    }

	$delete_Flag = 1;
    $sql="INSERT INTO sub_category ( Category_ID , Sub_Category_Name , 	SubCategory_Date , Delete_Flag) VALUES ('$category_id' , '$sub_category_name', NOW(), '$delete_Flag')";
    
	$conn->query($sql);
    header('location:sub_category.php');

?> 