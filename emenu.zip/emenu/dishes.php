<?php include('header.php'); ?>
<body>
    <div class="container_fluid">
    	<div class="container">

    	<!-- start header top -->
    	<?php include('nav.php'); ?>
        <!-- end header top -->
        <!-- start dishes list view -->
        <div class="row">
                <div class="col-md-12"><h2> Dishes </h2></div>

                <!-- for add new dishes   -->
                  <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#adddishes">Add New Dishes</button>
                        <div class="modal fade" id="adddishes" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Add New Dishes</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="add_dishes.php" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="dishes_name" class="col-form-label">Dishes Name</label>
								            <input type="text" class="form-control" id="dishes_name" name="dishes_name">
								          </div>
								          <div class="form-group">
								            <label for="dishes_photo" class="col-form-label">Dishes Photo</label>
								            <input type="file" class="form-control" id="dishes_photo" name="dishes_photo">
								          </div>
								          <div class="form-group">
								            <label for="dishes_price" class="col-form-label">Dishes Price</label>
								            <input type="text" class="form-control" id="dishes_price" name="dishes_price">
								          </div>
								          <!-- retreving category list -->
								          <div class="form-group">
								           
								            <select name ="category_name_list" class="form-control">
								            	<option>Choose Categories Type</option>
								           <?php
												$sql="select * from category order by Category_ID asc";
												$query=$conn->query($sql);
												
												while($row=$query->fetch_array()){
													
													?>
                                             <option value="<?php echo $row['Category_Name'] ?>"> <?php echo $row['Category_Name'] ?></option>
                                             <?php    
					                         }

                                             ?>
 												 
											</select>
										   
								          </div>

								          <!-- retreving sub category list -->
								          <div class="form-group">
								           
								            <select name ="sub_category_name_list" class="form-control">
								            	<option>Choose Sub Categories Type </option>
								           <?php
												$sql="select * from sub_category order by Sub_Category_Name asc";
												$query=$conn->query($sql);
												
												while($row=$query->fetch_array()){
													
													?>
                                             <option value="<?php echo $row['Sub_Category_Name'] ?>"> <?php echo $row['Sub_Category_Name'] ?></option>
                                             <?php    
					                         }

                                             ?>
 												 
											</select>
										   
								          </div>

								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-primary">Save</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>

                <!-- end for adding new dishes  -->
                <table class="table table-hover">
				  <thead>
				    <tr>
				      <th scope="col">#</th>
				      <th scope="col">Dishes Name</th>
				      <th scope="col">Dishes Photo</th>
				      <th scope="col">Dishes Price</th>
				      <th scope="col">Category Name</th>
				       <th scope="col">Sub Category Name</th>
				      <th scope="col">Edit</th>
				      <th scope="col">Delete</th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
					$sql="select * from dishes order by Dishes_Id asc";
					$query=$conn->query($sql);
					
					while($row=$query->fetch_array()){

						$no += 1;
						$Dishes_Name = $row['Dishes_Name'];
						$Dishes_Price = $row['Dishes_Price'];
						$Dishes_Photo = $row['Dishes_Photo'];
						$choose_cat_id = $row['Category_ID'];
						$choose_subcat_id = $row['Sub_Category_Id'];
						$cat_query = "select Category_Name from category WHERE Category_ID = $choose_cat_id ";
						$query_cat=$conn->query($cat_query);
						while($rowcat=$query_cat->fetch_array()){
							$Category_Name = $rowcat['Category_Name'];
						}
						

						$subcat_query = "select Sub_Category_Name from sub_category WHERE  	Sub_Category_Id = $choose_subcat_id";
						$query_subcat = $conn->query($subcat_query);
						while($rowsub = $query_subcat->fetch_array()){
							$Sub_Category_Name = $rowsub['Sub_Category_Name'];
						}

						?>
						<tr>
							<th scope="row"><?php echo $no ; ?></th>
							<td><?php echo $Dishes_Name ?></td>
							<td><img src="<?php if(empty($Dishes_Photo)){echo "upload/noimage.jpg";} else{echo $Dishes_Photo ;} ?>" height="80px" width="100px"></td>
							<td><?php echo $Dishes_Price ?> MMK</td>
                            <td><?php echo $Category_Name ?></td>
							<td><?php echo $Sub_Category_Name ?></td>
							<td>
								<button type="button" class="btn btn-success" data-toggle="modal" data-target="#edit_dishes<?php echo $row['Dishes_Id']; ?>">Edit</button>
							</td>
							<td>
							    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#deletedishes<?php echo $row['Dishes_Id']; ?>">Delete</button>
							</td>
						</tr>

						<!-- start Edit Dishes modal box  -->

                  
                        <div class="modal fade" id="edit_dishes<?php echo $row['Dishes_Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Edit Dishes</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="edit_dishes.php?Dishes_Id=<?php echo $row['Dishes_Id']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="dishes_name" class="col-form-label">Dishes Name</label>
								            <input type="text" class="form-control" id="dishes_name" value='<?php echo $Dishes_Name; ?> ' name="dishes_name">
								          </div>
								          <div class="form-group">
								            <label for="dishes_photo" class="col-form-label">Dishes Photo</label>
								            
								           <img src="<?php if(empty($Dishes_Photo)){echo "upload/noimage.jpg";} else{echo $Dishes_Photo ;} ?>" height="80px" width="100px" name="dishes_photo">
								          </div>

								          <div class="form-group">
								            <label for="dishes_price" class="col-form-label">Prices</label>
								            <input type="text" class="form-control" id="dishes_price" value='<?php echo $Dishes_Price; ?> ' name="dishes_price">
								          </div>

								          <div class="form-group">
								          	  <label for="edit_category_list" class="col-form-label">Category Name</label>
                                              <select name="edit_category_list">
                                                 <option value="<?php echo $Category_Name ?>"> <?php echo $Category_Name?></option>
                                                 <?php
                                                 $sql_editcat="select * from category order by Category_ID asc";
												 $edit_catquery=$conn->query($sql_editcat);
												
												 while($row_editcate=$edit_catquery->fetch_array()){
												 ?>

												 <option value="<?php echo $row_editcate['Category_Name'] ?>"> <?php echo $row_editcate['Category_Name'] ?></option>
												<?php
                                                  }
												?>

                                              </select>
								          </div>
								          <div class="form-group">
								          	  <label for="edit_subcategory_list" class="col-form-label">Sub Category Name</label>
                                              <select name="edit_subcategory_list">
                                                 <option value="<?php echo $Sub_Category_Name ?>"> <?php echo $Sub_Category_Name ?></option>
                                                 <?php
                                                 $sql_editsubcat="select * from sub_category order by Sub_Category_Id asc";
												 $edit_subcatquery=$conn->query($sql_editsubcat);
												
												 while($row_editsubcate=$edit_subcatquery->fetch_array()){
												 ?>

												 <option value="<?php echo $row_editsubcate['Sub_Category_Name'] ?>"> <?php echo $row_editsubcate['Sub_Category_Name'] ?></option>
												<?php
                                                  }
												?>

                                              </select>
								          </div>

								         
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-primary">Save</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>

               
                        <!-- end Edit Dishes modal box-->


                        <!--  start Delete Dishes modal box -->
                         <div class="modal fade" id="deletedishes<?php echo $row['Dishes_Id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                             <div class="modal-dialog" role="document">
								    <div class="modal-content">
								      <div class="modal-header">
								        <h5 class="modal-title" id="exampleModalLabel">Delete Dishes</h5>
								        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
								          <span aria-hidden="true">&times;</span>
								        </button>
								      </div>
								      <div class="modal-body">
								        <form method="POST" action="delete_dishes.php?DishesID=<?php echo $row['Dishes_Id']; ?>" enctype="multipart/form-data">
								          <div class="form-group">
								            <label for="category-name" class="col-form-label">Dishes Name : <?php echo $Dishes_Name; ?></label>
								            
								          </div>
								         
								        
								      </div>
								      <div class="modal-footer">
								        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
								        <button type="submit" class="btn btn-danger">Delete</button>
								        </form>
								      </div>
								    </div>
  								</div>
						</div>


                        <!-- end Delete Category modal box  -->
						<?php
					}
				?>
				   
				  </tbody>
				</table>
        <div>

       
        <!-- end categories list views -->
        
        </div>
         
    </div>

</body>
</html>