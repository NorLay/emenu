<?php
	include('connect.php');
    $CategoryID = $_GET['CategoryID'];
	$category_name=$_POST['category_name'];
	//echo $category_name; exit;
	
	//echo gettype($date); exit;
	$delete_Flag = 1;
	 
    $sql="UPDATE category SET Category_Name='$category_name' , Category_Date = NOW() 
    WHERE Category_ID =  '$CategoryID' ";
    
	$conn->query($sql);
    header('location:category.php');

?> 